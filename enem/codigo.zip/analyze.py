import pathlib,zipfile,json,hashlib,time,io,subprocess,contextlib
import numpy as np,pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import r2_score,mean_absolute_error
P=pathlib.Path('/tmp/enem');O=P/'out';O.mkdir(exist_ok=True)
NOTES=['NU_NOTA_'+x for x in ['CN','CH','LC','MT','REDACAO']]
def dump(name,x):
 def conv(o):
  if isinstance(o,np.generic):return o.item()
  raise TypeError(str(type(o)))
 (O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=conv,allow_nan=False))
def stats(d,groups):
 rows=[]
 for keys,g in d.groupby(groups,dropna=False,observed=True):
  if not isinstance(keys,tuple):keys=(keys,)
  row={k:str(v) for k,v in zip(groups,keys)};n=len(g)
  row.update(n=n,top1000=int(g.top1000.sum()),top5=int(g.top5.sum()),top1=int(g.top1.sum()),red_top=int(g.red_top.sum()),mean=float(g.obj.mean()),median=float(g.obj.median()),p10=float(g.obj.quantile(.1)),p90=float(g.obj.quantile(.9)))
  for k in NOTES:row[k]=float(g[k].mean()) if g[k].notna().any() else None
  for target in ['top1000','top5','top1','red_top']:row[target+'_pct']=100*row[target]/n
  rows.append(row)
 return rows
for year,filename in [(2025,'enem.zip'),(2023,'enem2023.zip')]:
 path=P/filename
 if not path.exists():continue
 with zipfile.ZipFile(path) as z:
  names=[n for n in z.namelist() if n.lower().endswith('.csv') and ('RESULTADOS' in n or 'MICRODADOS_ENEM' in n or 'PARTICIPANTES' in n)]
  result={'year':year,'archive_bytes':path.stat().st_size,'sha256':hashlib.file_digest(open(path,'rb'),'sha256').hexdigest(),'files':{},'groups':{}}
  frames={}
  for n in names:
   with (open(P/'extracted2025'/n,'rb') if year==2025 else z.open(n)) as f:header=io.TextIOWrapper(f,encoding='latin1',newline=None).readline().strip().split(';')
   result['files'][n]=header
   use=[c for c in header if c in NOTES or c.startswith('Q0') or c in ['TP_FAIXA_ETARIA','TP_SEXO','TP_COR_RACA','TP_ESCOLA','IN_TREINEIRO','TP_ST_CONCLUSAO','TP_ENSINO','SG_UF_ESC','SG_UF_PROVA','TP_DEPENDENCIA_ADM_ESC','TP_LOCALIZACAO_ESC','TP_PRESENCA_CN','TP_PRESENCA_CH','TP_PRESENCA_LC','TP_PRESENCA_MT','TP_STATUS_REDACAO']]
   chunks=[]
   with (open(P/'extracted2025'/n,'rb') if year==2025 else z.open(n)) as f:
    for c in pd.read_csv(f,sep=';',encoding='latin1',usecols=use,chunksize=200000,low_memory=False):chunks.append(c)
   d=pd.concat(chunks,ignore_index=True);frames['results' if NOTES[0] in d else 'profile']=d
   print(year,n,len(d),flush=True)
  if 'profile' in frames:
   d=frames['profile']; result['profile_n']=len(d);result['profile']={}
   for c in ['TP_SEXO','TP_COR_RACA','Q001','Q002','Q006','TP_ESCOLA','IN_TREINEIRO']:
    if c in d:result['profile'][c]=[{'category':str(k),'n':int(v)} for k,v in d[c].fillna('NA').value_counts().sort_index().items()]
  d=frames['results'];result['total_n']=len(d)
  result['complete_four_n']=int(d[NOTES[:4]].notna().all(axis=1).sum())
  result['present_each']={k:int((d[k]==1).sum()) for k in d if k.startswith('TP_PRESENCA')}
  result['school_known_all_n']=int(d.TP_DEPENDENCIA_ADM_ESC.notna().sum())
  # one common analytical population: all 4 objective scores positive, and nontraining where known.
  mask=d[NOTES[:4]].gt(0).all(axis=1)
  if 'IN_TREINEIRO' in d:mask &= d.IN_TREINEIRO.eq(0)
  d=d.loc[mask].copy();d['obj']=d[NOTES[:4]].mean(axis=1)
  result['n']=len(d);result['excludes_training']='IN_TREINEIRO' in d
  for label,size in [('top1000',1000),('top5',int(np.ceil(len(d)*.05))),('top1',int(np.ceil(len(d)*.01)))]:
   cut=float(d.obj.nlargest(size).min());d[label]=d.obj.ge(cut);result[label]={'cutoff':cut,'n':int(d[label].sum())}
  redcut=float(d.NU_NOTA_REDACAO.dropna().nlargest(1000).min());d['red_top']=d.NU_NOTA_REDACAO.ge(redcut);result['red_top']={'cutoff':redcut,'n':int(d.red_top.sum())}
  result['overall']={'mean':float(d.obj.mean()),'median':float(d.obj.median()),'scores':{k:float(d[k].mean()) for k in NOTES}}
  if 'TP_SEXO' in d:
   d['sex_race']=d.TP_SEXO.astype(str)+'_'+d.TP_COR_RACA.astype(str)
   d['sex_blackwhite']=d.TP_SEXO.astype(str)+'_'+d.TP_COR_RACA.map({0:'Não declarada',1:'Branca',2:'Negra',3:'Negra',4:'Amarela',5:'Indígena',6:'Não dispõe'}).fillna('Sem informação')
  groups=['TP_SEXO','TP_COR_RACA','sex_race','sex_blackwhite','Q006','Q001','Q002','Q024','Q025','TP_ESCOLA','TP_DEPENDENCIA_ADM_ESC','SG_UF_ESC','SG_UF_PROVA','TP_LOCALIZACAO_ESC','TP_FAIXA_ETARIA']
  for c in groups:
   if c in d:result['groups'][c]=stats(d,[c])
  if 'Q006' in d:
   for gs in [['TP_SEXO','Q006'],['sex_blackwhite','Q006'],['TP_ESCOLA','Q006']]:result['groups']['_X_'.join(gs)]=stats(d,gs)
   # Adaptation, explicitly not the original ten-item infrastructure index.
   d['low_income']=d.Q006.isin(['A','B','C']) # family income <=1.5 minimum wages, NOT per capita poverty
   d['vulnerability4']=d.low_income.astype(int)+d.Q024.eq('A').astype(int)+d.Q025.eq('A').astype(int)+d.TP_ESCOLA.eq(2).astype(int)
   result['groups']['vulnerability4']=stats(d,['vulnerability4'])
   result['groups']['vulnerability4_sexrace']=stats(d,['vulnerability4','sex_blackwhite'])
   # Model: reproducible sample and held-out evaluation, no target-derived predictors.
   sample=d.sample(n=min(250000,len(d)),random_state=20261111)
   idxtrain,idxtest=train_test_split(np.arange(len(sample)),test_size=.2,random_state=20261111)
   family=[c for c in d if c.startswith('Q0')];demo=['TP_FAIXA_ETARIA','TP_SEXO','TP_COR_RACA'];school=['TP_ESCOLA','TP_DEPENDENCIA_ADM_ESC','SG_UF_ESC']
   models=[]
   for label,cols in [('Perfil demográfico',demo),('Família e recursos',family),('Família, recursos, demografia e escola',family+demo+school)]:
    x=sample[cols].astype(str).fillna('NA');enc=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=np.nan);xt=enc.fit_transform(x.iloc[idxtrain]);xv=enc.transform(x.iloc[idxtest]);y=sample.obj.to_numpy()
    model=HistGradientBoostingRegressor(categorical_features=np.ones(len(cols),dtype=bool),max_iter=160,max_leaf_nodes=31,l2_regularization=10,random_state=20261111)
    model.fit(xt,y[idxtrain]);pred=model.predict(xv)
    row={'label':label,'features':cols,'train_n':len(idxtrain),'test_n':len(idxtest),'r2_test':float(r2_score(y[idxtest],pred)),'mae_test':float(mean_absolute_error(y[idxtest],pred))};models.append(row);print('model',row,flush=True)
   result['models']=models
  dump(f'analysis-{year}.json',result)
  print('SAVED',year,flush=True)
