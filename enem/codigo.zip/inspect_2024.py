import io,subprocess,zipfile,re,pathlib
u='http://download.inep.gov.br/microdados/microdados_enem_2024.zip'
h=subprocess.check_output(['curl','-sSI','--max-time','30',u]).decode();size=int(re.search(r'Content-Length: (\d+)',h,re.I)[1])
class Remote(io.RawIOBase):
 def __init__(self):self.pos=0
 def seekable(self):return True
 def tell(self):return self.pos
 def seek(self,off,whence=0):
  self.pos=off if whence==0 else self.pos+off if whence==1 else size+off
  return self.pos
 def read(self,n=-1):
  if n<0:n=size-self.pos
  if n==0:return b''
  end=min(size,self.pos+n)-1
  b=subprocess.check_output(['curl','-sf','--max-time','40','-r',f'{self.pos}-{end}',u]);self.pos+=len(b);return b
with zipfile.ZipFile(Remote()) as z:
 for n in z.namelist():
  if n.endswith('.csv') and ('PARTICIPANTES' in n or 'RESULTADOS' in n or 'MICRODADOS_ENEM' in n):
   print(n,z.getinfo(n).file_size,flush=True)
   with z.open(n) as f:print(io.TextIOWrapper(f,encoding='latin1',newline=None).readline(),flush=True)
  if 'leia' in n.lower() and n.lower().endswith('.pdf'):
   z.extract(n,'/tmp/enem/documentation2024')
print('DONE')
