Enem / Datafixers — análise de 11/11/2026

Fontes oficiais: https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/enem
Linux Debian 12, Python 3.11, pandas 1.5.3, numpy 1.24.2, scikit-learn 1.2.1, openpyxl 3.0.9, pypdf 3.4.1, p7zip.
Preparação Debian: apt-get install python3-pandas python3-sklearn python3-openpyxl python3-pypdf p7zip-full

1. python3 download_inspect.py
2. OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=4 python3 analyze.py
3. python3 supplement.py
4. Copiar /tmp/enem/out/*.json. Guardar dicionários e Leia-me, se necessários. Conferir hashes de analyze.py e validação supplement.py.
5. Apagar /tmp/enem e a VM temporária com seu disco. Nenhum microdado individual é publicado neste pacote.

Os arquivos 2025 usam Deflate64 em parte do ZIP; 7z é necessário, pois zipfile do Python não suporta esse método. O download HTTP foi o endpoint oficial que respondeu na VM de São Paulo nesta execução; o HTTPS falhou no Mac e em duas regiões de nuvem. Hashes dos ZIPs usados são registrados nos resultados.

Arquivo analyze.py: grupos, notas, top1000/top5/top1 e redação com todos os empates; 2023 exclui treineiros, 2025 não permite fazê-lo. Modelos categóricos de boosting com semente fixa, 200 mil no treino e 50 mil no teste. Sem treinamento nos resultados de teste.
Arquivo supplement.py: geografia escolar, limites de renda per capita sem pontos médios, adaptação de seis vulnerabilidades e segunda leitura para validar denominadores e cortes 2023 e médias por rede 2025. O índice exploratório vulnerability4 em analysis-2023.json não é o índice original e não é usado na narrativa. Para o índice apresentado, usar supplement.json/adverse6.
Arquivo inspect_2024.py: usa HTTP Range para conferir cabeçalhos e Leia-me sem baixar o ZIP inteiro.
Arquivo read_dictionary.py: extrai dicionários e passagens de documentação.

As perguntas mudaram de código em 2025: Q006 pergunta se o candidato possui renda; Q007 é renda familiar. Em 2023, Q006 é renda familiar. A análise de renda/nota utiliza APENAS 2023. As bases de participantes e resultados de 2024/2025 não têm chave de ligação, e nunca são unidas por linha ou por números sequenciais.

R² não é parcela de nota individual, porcentagem de causalidade ou probabilidade de aprovação. O novo modelo não reproduz a estatística de 85% do estudo original, que usava Censo Escolar 2017 e não disponibiliza código no texto da reportagem. O índice de seis condições também não replica o índice de dez original. A renda por pessoa usa classificação conservadora por teto de faixa, não renda exata observada.

Site e propostas sociais: pasta enem no repositório luizftoledo/datafixers. Nenhum envio às redes sociais é feito por estes scripts.
