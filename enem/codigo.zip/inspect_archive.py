import zipfile,pathlib,hashlib,io
from pypdf import PdfReader
p=pathlib.Path('/tmp/enem')
for path in p.glob('*.zip'):
 try:
  with zipfile.ZipFile(path) as z:
   print('\nARCHIVE',path.name,'bytes',path.stat().st_size,flush=True)
   for n in z.namelist():
    if n.lower().endswith('.csv'):
     print(n,z.getinfo(n).file_size,flush=True)
     with z.open(n) as f:print(io.TextIOWrapper(f,encoding='latin1',newline=None).readline().strip(),flush=True)
    if ('leia' in pathlib.Path(n).name.lower() and n.lower().endswith('.pdf')) or n.lower().endswith('.xlsx'):
     z.extract(n,p)
     if n.lower().endswith('.pdf'):
      try: print('\n'.join(x.extract_text() for x in PdfReader(p/n).pages),flush=True)
      except Exception as e:print(e)
 except zipfile.BadZipFile:print('not complete',path)
