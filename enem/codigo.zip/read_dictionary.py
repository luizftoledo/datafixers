import pathlib,zipfile,openpyxl,io
from pypdf import PdfReader
P=pathlib.Path('/tmp/enem')
for archive in ['enem.zip','enem2023.zip']:
 with zipfile.ZipFile(P/archive) as z:
  for n in z.namelist():
   if n.lower().endswith('.xlsx'):
    z.extract(n,P)
    w=openpyxl.load_workbook(P/n,read_only=True,data_only=True)
    print(archive,n,w.sheetnames)
    for sh in w:
     print('SHEET',sh.title)
     for row in sh.values:
      vals=[str(v) for v in row if v is not None]
      if vals:print(' | '.join(vals))
   if 'leia' in pathlib.Path(n).name.lower() and n.lower().endswith('.pdf'):
    z.extract(n,P)
    print('PDF',archive,n)
    for i,page in enumerate(PdfReader(P/n).pages):
     txt=page.extract_text()
     if any(k in txt.lower() for k in ['sequencial','vínculo','vincul','separa','inscrição','relaciona','cruzamento']):print('PAGE',i+1,txt)
