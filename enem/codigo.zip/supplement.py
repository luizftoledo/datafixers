import zipfile,pathlib,json,io
import pandas as pd,numpy as np
P=pathlib.Path('/tmp/enem');O=P/'out';O.mkdir(exist_ok=True)
cols=['IN_TREINEIRO','TP_SEXO','TP_COR_RACA','TP_ESCOLA','TP_DEPENDENCIA_ADM_ESC','CO_MUNICIPIO_ESC','NO_MUNICIPIO_ESC','SG_UF_ESC','SG_UF_PROVA','Q001','Q002','Q005','Q006','Q010','Q023','Q024','Q025']+['NU_NOTA_'+x for x in ['CN','CH','LC','MT','REDACAO']]
with zipfile.ZipFile(P/'enem2023.zip') as z:
 n=next(n for n in z.namelist() if 'MICRODADOS_ENEM_2023.csv' in n)
 with z.open(n) as f:d=pd.read_csv(f,sep=';',encoding='latin1',usecols=cols,low_memory=False)
notes=['NU_NOTA_'+x for x in ['CN','CH','LC','MT']];d=d[(d.IN_TREINEIRO==0)&d[notes].gt(0).all(axis=1)].copy();d['obj']=d[notes].sum(axis=1)/4
n=len(d);cut=d.obj.nlargest(1000).min();cut5=d.obj.nlargest(int(np.ceil(n*.05))).min();d['top1000']=d.obj>=cut;d['top5']=d.obj>=cut5
upper=dict(zip('ABCDEFGHIJKLMNOPQ',[0,1,1.5,2,2.5,3,4,5,6,7,8,9,10,12,15,20,np.inf]));lower=dict(zip('ABCDEFGHIJKLMNOPQ',[0,0,1,1.5,2,2.5,3,4,5,6,7,8,9,10,12,15,20]))
d['pc_upper']=d.Q006.map(upper)/d.Q005;d['pc_lower']=d.Q006.map(lower)/d.Q005
d['pc_group']=np.select([d.pc_upper.le(1/3),d.pc_lower.lt(1/3),d.pc_lower.ge(2)],['Até 1/3 SM por pessoa (limite superior)','Faixa cruza 1/3 SM por pessoa','Pelo menos 2 SM por pessoa (limite inferior)'],default='Demais faixas')
def agg(frame,c):
 out=[]
 for key,g in frame.groupby(c,dropna=False):
  out.append({'category':str(key),'n':len(g),'top1000':int(g.top1000.sum()),'top5':int(g.top5.sum()),'mean':float(g.obj.mean()),'top5_pct':float(100*g.top5.mean()),'red_mean':float(g.NU_NOTA_REDACAO.mean())})
 return out
res={'n':n,'top1000_n':int(d.top1000.sum()),'top1000_cutoff':float(cut),'top5_n':int(d.top5.sum()),'top5_cutoff':float(cut5),'per_capita':agg(d,'pc_group')}
d['parent_higher']=np.select([d.Q001.isin(['F','G'])&d.Q002.isin(['F','G']),d.Q001.isin(['F','G'])|d.Q002.isin(['F','G'])],['Ambos com superior/pós','Um com superior/pós'],default='Nenhum superior informado');res['parents_combined']=agg(d,'parent_higher')
# Six-condition adaptation on rows with a known state/municipal/private/federal school; no imputation of infrastructure.
s=d[d.TP_DEPENDENCIA_ADM_ESC.notna()].copy();s['adverse6']=s.pc_upper.le(1/3).astype(int)+s.TP_DEPENDENCIA_ADM_ESC.isin([2,3]).astype(int)+sum(s[q].eq('A').astype(int) for q in ['Q010','Q023','Q024','Q025']);res['adverse6']=agg(s,'adverse6');res['adverse6_school_n']=len(s)
res['adverse6_extreme_uf']=agg(s[s.adverse6==6],'SG_UF_ESC')
caps={1100205,1200401,1302603,1400100,1501402,1600303,1721000,2111300,2211001,2304400,2408102,2507507,2611606,2704302,2800308,2927408,3106200,3205309,3304557,3550308,4106902,4205407,4314902,5002704,5103403,5208707,5300108}
d['school_geography']=np.select([d.CO_MUNICIPIO_ESC.isna(),d.CO_MUNICIPIO_ESC.isin(caps)],['Escola sem município informado','Escola em capital'],default='Escola fora de capital');res['capital']=agg(d,'school_geography')
top=d[d.top1000];valid=d[d.CO_MUNICIPIO_ESC.notna()];res['school_municipalities']={'all_distinct':int(valid.CO_MUNICIPIO_ESC.nunique()),'top_distinct':int(top.CO_MUNICIPIO_ESC.nunique()),'all_known_n':len(valid),'top_known_n':int(top.CO_MUNICIPIO_ESC.notna().sum())};res['top_school_cities']=[{'city':str(key[0]),'uf':str(key[1]),'n':len(g)} for key,g in top[top.CO_MUNICIPIO_ESC.notna()].groupby(['NO_MUNICIPIO_ESC','SG_UF_ESC'])];res['top_school_cities'].sort(key=lambda x:-x['n'])
# Streaming independent checks for 2025, totals and means, directly on extracted result CSV.
check={'2023':{'n':n,'top1000_n':res['top1000_n'],'top1000_cutoff':float(cut),'top5_n':res['top5_n'],'top5_cutoff':float(cut5)}}
total=0;eligible=0;sums=np.zeros(4);by={}
for ch in pd.read_csv(P/'extracted2025/microdados_enem_2025/DADOS/RESULTADOS_2025.csv',sep=';',encoding='latin1',usecols=notes+['TP_DEPENDENCIA_ADM_ESC'],chunksize=200000):
 total+=len(ch);ch=ch[ch[notes].gt(0).all(axis=1)];eligible+=len(ch);sums+=ch[notes].sum().to_numpy()
 for k,g in ch.groupby('TP_DEPENDENCIA_ADM_ESC',dropna=False):
  k=str(k);v=by.setdefault(k,{'n':0,'sum_obj':0.});v['n']+=len(g);v['sum_obj']+=float((g[notes].sum(axis=1)/4).sum())
check['2025']={'total_n':total,'n':eligible,'mean':float(sums.sum()/4/eligible),'schools':by}
for year in [2023,2025]:
 a=json.load(open(O/f'analysis-{year}.json'));assert a['n']==check[str(year)]['n']
 for c,rows in a['groups'].items():
  assert sum(r['n'] for r in rows)==a['n'],(year,c,'count')
  assert sum(r['top1000'] for r in rows)==a['top1000']['n'],(year,c,'top')
 if year==2023:
  assert a['top1000']['n']==res['top1000_n'];assert abs(a['top1000']['cutoff']-cut)<1e-8;assert a['top5']['n']==res['top5_n']
 else:
  assert abs(a['overall']['mean']-check['2025']['mean'])<1e-8
  for r in a['groups']['TP_DEPENDENCIA_ADM_ESC']:
   k=r['TP_DEPENDENCIA_ADM_ESC'];v=by[k];assert r['n']==v['n'];assert abs(r['mean']-v['sum_obj']/v['n'])<1e-8
check['status']='passed';res['validation']=check
(O/'supplement.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print('SUPPLEMENT SAVED; independent checks passed',flush=True)
