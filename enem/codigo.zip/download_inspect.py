"""Download official archives on a temporary Linux worker; retain no student-level output."""
import pathlib,subprocess
p=pathlib.Path('/tmp/enem');p.mkdir(exist_ok=True)
for year,name in [(2025,'enem.zip'),(2023,'enem2023.zip')]:
 path=p/name
 if not path.exists():
  url=f'http://download.inep.gov.br/microdados/microdados_enem_{year}.zip'
  subprocess.run(['curl','-fL','--connect-timeout','20','--max-time','900',url,'-o',str(path)],check=True)
 if year==2025:subprocess.run(['7z','x',str(path),'-o'+str(p/'extracted2025'),'-y','*/DADOS/*'],check=True)
print('Run analyze.py, then supplement.py. Delete /tmp/enem and the temporary VM after copying aggregates/documentation.')
